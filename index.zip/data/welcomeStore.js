export const welcomeSettings = {
  // Example:
  // "guildID": {
  //   channel: "channelID",
  //   message: "🎉 Welcome {user} to {server}! You're member #{memberCount}"
  // }
};
